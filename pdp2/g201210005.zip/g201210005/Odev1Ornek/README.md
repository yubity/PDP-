# Odev1Ornek
1. Ödevinizde deneyebileceğiniz örnek bir depo. <br>
Ekran Çıktısı aşağıdaki gibi olmalıdır.<br><br>

<div style="text-align:left; font-size:10pt;">
Sınıf: Atm.java<br>
Javadoc Satır Sayısı: 10<br>
Yorum Satır Sayısı: 1<br>
Kod Satır Sayısı: 11<br>
LOC: 28<br>
Fonksiyon Sayısı: 2<br>
Yorum Sapma Yüzdesi: % 166.67<br>
-----------------------------------------<br>
Sınıf: Hesap.java<br>
Javadoc Satır Sayısı: 3<br>
Yorum Satır Sayısı: 4<br>
Kod Satır Sayısı: 35<br>
LOC: 53<br>
Fonksiyon Sayısı: 6<br>
Yorum Sapma Yüzdesi: % -46.67<br>
-----------------------------------------<br>
Sınıf: Kart.java<br>
Javadoc Satır Sayısı: 5<br>
Yorum Satır Sayısı: 1<br>
Kod Satır Sayısı: 17<br>
LOC: 33<br>
Fonksiyon Sayısı: 3<br>
Yorum Sapma Yüzdesi: % -5.88<br>
-----------------------------------------<br>
Sınıf: MasterKart.java<br>
Javadoc Satır Sayısı: 0<br>
Yorum Satır Sayısı: 0<br>
Kod Satır Sayısı: 17<br>
LOC: 22<br>
Fonksiyon Sayısı: 3<br>
Yorum Sapma Yüzdesi: % -100.00<br>
-----------------------------------------<br>
Sınıf: Program.java<br>
Javadoc Satır Sayısı: 4<br>
Yorum Satır Sayısı: 6<br>
Kod Satır Sayısı: 18<br>
LOC: 33<br>
Fonksiyon Sayısı: 1<br>
Yorum Sapma Yüzdesi: % 48.15<br>
</div>

