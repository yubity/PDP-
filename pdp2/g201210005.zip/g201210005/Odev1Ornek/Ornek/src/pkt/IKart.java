package pkt;

public interface IKart {
	public boolean girisKontrol(String sifre);
	public IHesap getHesap();
}
